﻿1. Compile the server.c file using : gcc -o server.out server.c
2. Compile the client.c file using : gcc -o client.out client.c
3. Run server using :    ./server.out 8080
4. Run clients using:      ./client.out 127.0.0.1 8080
5. Send data from client
6. Send data from server
7. Enter “exit” to exit out of the client.
﻿1. Compile using:
   1. gcc client.c
2. Run using:
   1. ./a.out http://hostname/path